

<?php 

function create_custom_post_type() {
    register_post_type('Services', [ 
        'labels' => [
            'name' => __('Services'),
            'singular_name' => __('Service'),
            'add_new' => __('Add New'),
            'add_new_item' => __('Add New Service'),
            'edit_item' => __('Edit Service'),
            'new_item' => __('New Service'),
            'view_item' => __('View Service'),
            'search_items' => __('Search Service'),
        ],
        'public' => true,
        'has_archive' => true,
        'rewrite' => ['slug' => 'services'],
        'menu_icon' => 'dashicons-admin-post',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
        'show_in_rest' => true, 
    ]);
}
add_action('init', 'create_custom_post_type');

function register_product_post_type() {
    register_post_type('product', [
        'labels' => [
            'name' => 'Products',
            'singular_name' => 'Product',
        ],
        'public' => true,
        'has_archive' => true,
        'rewrite' => ['slug' => 'products'],
        'menu_icon' => 'dashicons-cart',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
        'show_in_rest' => true,
    ]);
}
add_action('init', 'register_product_post_type');

function enable_thumbnails_for_all() {
    add_theme_support('post-thumbnails', ['post', 'page', 'Services', 'product']);
}
add_action('after_setup_theme', 'enable_thumbnails_for_all');
add_image_size('Services-thumb', 400, 300, true);

function allow_svg_uploads($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'allow_svg_uploads');