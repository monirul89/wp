<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'goldenskyfoot' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'D[GT,x:Elh$j;[_g:JqhibNHr(N< =i[e(wg4e398^ |zddPk{x,_ifa_*DKO{l#' );
define( 'SECURE_AUTH_KEY',  'Ej7~%@VT@1>1,Mfy|~`M~oPK6?!x+Z)OQt=Ix!ORY{^a!Be~Kq4gu^Ks_h`%eG]f' );
define( 'LOGGED_IN_KEY',    'b<gYO4KFV&@G8kJ@8:mw{j{k@On[q-TOG/4uLGD/2Ib;@{Jh+Dg/ !M{14@xIrsD' );
define( 'NONCE_KEY',        'y|0<lpWvF7jDL>)43}IV^epvJ;?!bbDo M90RS~^f7eNn/]DcDC/x%MPoWDQ8eu&' );
define( 'AUTH_SALT',        '.@:94#+77dfR59+g&Y&0D0r&Srz$^i_Tst[DPp;1TP{C1g{r$0jqu0d`lQ5c12M*' );
define( 'SECURE_AUTH_SALT', 'y<5sl)_sQjy-lHf-T!Wvf0{3 )_sD_yQt.P]zp0]F:<uEhu<XmFCy/fnX~a5Nm{P' );
define( 'LOGGED_IN_SALT',   '[^6e1yL]*S0qZZcP2mm[zA8Bmx<mvu%_-o:GRS}A!!ObFKIml:8_*7FZ]JwGOR7C' );
define( 'NONCE_SALT',       'Eaw6f!Zv(4YN`5AL7g.X.|##l)y_$)ZFTwBE-k7Xth-LNusNC75#(~2?|;A7{k:V' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
